export const orbitcontrolsettings = {
  enableZoom: true,
  enablePan: true,
  enableRotate: true,
  autoRotate: true,
  autoRotateSpeed: 0.5,
  minDistance: 3,
  maxDistance: 40,
};
