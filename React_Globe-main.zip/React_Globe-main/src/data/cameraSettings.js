export const cameraSettings = {
  fov: 50,
};
